
'use client';

import { useState, useEffect } from 'react';

export default function Home() {
  const [sessionTaps, setSessionTaps] = useState(0);
  const [totalTaps, setTotalTaps] = useState(0);
  const [communityTaps, setCommunityTaps] = useState(935129);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleTap = () => {
    setIsAnimating(true);
    setSessionTaps(prev => prev + 1);
    setTotalTaps(prev => prev + 1);
    setCommunityTaps(prev => prev + 1);
    
    setTimeout(() => {
      setIsAnimating(false);
    }, 200);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText('347k5f1WLRYe81roRcLBWDR6k3eCRunaqetQPW6pbonk');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden bg-gradient-to-br from-neutral-900 via-stone-900 to-black">
      {/* Floating Nature Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-10 text-sm opacity-60 animate-bounce">🍃</div>
        <div className="absolute top-20 right-20 text-sm opacity-50 animate-pulse">🌿</div>
        <div className="absolute top-40 left-1/4 text-xs opacity-40 animate-bounce">🍀</div>
        <div className="absolute top-60 right-1/3 text-sm opacity-55 animate-pulse">🌾</div>
        <div className="absolute top-80 left-1/2 text-xs opacity-45 animate-bounce">🌱</div>
        <div className="absolute bottom-40 left-20 text-sm opacity-50 animate-pulse">🍃</div>
        <div className="absolute bottom-60 right-10 text-xs opacity-60 animate-bounce">🌿</div>
        <div className="absolute bottom-80 left-1/3 text-sm opacity-40 animate-pulse">🍀</div>
        <div className="absolute bottom-20 right-1/4 text-xs opacity-55 animate-bounce">🌾</div>
        <div className="absolute top-1/2 left-10 text-sm opacity-45 animate-pulse">🌱</div>
      </div>

      {/* Background Circles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-20 h-20 bg-white bg-opacity-10 rounded-full animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-16 h-16 bg-white bg-opacity-10 rounded-full animate-bounce"></div>
        <div className="absolute top-1/2 right-0 w-32 h-32 bg-white bg-opacity-5 rounded-full animate-pulse"></div>
        <div className="absolute bottom-1/2 left-0 w-24 h-24 bg-white bg-opacity-10 rounded-full animate-bounce"></div>
      </div>

      {/* Header */}
      <div className="text-center mb-8 z-10">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-2 drop-shadow-lg">
          🦎 LIZARD TAPPER
        </h1>
        <p className="text-2xl md:text-3xl text-gray-100 font-semibold drop-shadow-md">
          $LIZARD 🦎
        </p>
      </div>

      {/* Main Content */}
      <div className="flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-16 max-w-6xl w-full z-10">
        {/* Lizard Container */}
        <div className="relative">
          <div className={`transition-transform duration-200 ${isAnimating ? 'scale-95' : 'scale-100'}`}>
            <div className="relative w-80 h-80 md:w-96 md:h-96 bg-gradient-to-br from-amber-800 to-amber-900 rounded-3xl shadow-2xl flex items-center justify-center overflow-hidden border-4 border-amber-200 border-opacity-60 cursor-pointer hover:scale-105 transition-transform"
                 onClick={handleTap}>
              <img 
                alt="Lizard idle" 
                width={320} 
                height={320} 
                className={`object-contain transition-all duration-200 ${isAnimating ? 'scale-110' : 'scale-100'}`}
                src="https://static.readdy.ai/image/be05dbb09810a06e9b3c6d284175c5c1/de11081900385f3ab24f9231d1a1ebe0.png"
              />
            </div>
          </div>
          
          {/* Corner Counters */}
          <div className="absolute -top-4 -right-4 bg-amber-700 text-white font-bold text-xs px-2 py-1 rounded-full shadow-lg border-2 border-white border-opacity-50">
            {sessionTaps}
          </div>
          <div className="absolute -top-4 -left-4 bg-stone-800 text-white font-bold text-xs px-2 py-1 rounded-full shadow-lg border-2 border-white border-opacity-50">
            {totalTaps}
          </div>
          
          {/* Global Counter */}
          <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-amber-700 to-amber-800 text-white font-bold text-sm px-4 py-2 rounded-full shadow-lg border-2 border-white border-opacity-50">
            🌍 {communityTaps.toLocaleString()}
          </div>
        </div>

        {/* Right Panel */}
        <div className="flex flex-col items-center gap-6">
          {/* Tap Button */}
          <button 
            onClick={handleTap}
            className="bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white font-bold text-2xl md:text-3xl px-8 py-4 rounded-full shadow-xl transition-all duration-200 hover:scale-105 active:scale-95 min-w-[200px] whitespace-nowrap cursor-pointer"
          >
            TAP ME! 👆
          </button>

          {/* Contract Address */}
          <div className="bg-stone-800 bg-opacity-70 rounded-xl p-4 max-w-xs md:max-w-md backdrop-blur-sm border border-white border-opacity-20">
            <div className="text-center">
              <p className="text-xs text-gray-300 mb-1">CONTRACT ADDRESS</p>
              <p 
                className="text-sm md:text-base break-all text-white cursor-pointer hover:text-amber-300 transition-colors"
                onClick={copyToClipboard}
              >
                347k5f1WLRYe81roRcLBWDR6k3eCRunaqetQPW6pbonk
              </p>
              <p className="text-xs text-gray-300 mt-1">📋 Click to copy</p>
            </div>
          </div>

          {/* Social Button */}
          <a 
            href="https://x.com/lizardonbonk" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="bg-black bg-opacity-50 hover:bg-opacity-70 text-white font-semibold px-6 py-3 rounded-full transition-all duration-200 hover:scale-105 backdrop-blur-sm border border-white border-opacity-20 flex items-center gap-2 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-twitter-x-fill w-5 h-5 flex items-center justify-center"></i>
            Follow @lizardonbonk
          </a>

          {/* Stats */}
          <div className="text-center text-gray-100 text-sm space-y-2">
            <p className="flex items-center justify-center gap-2">
              <span className="inline-block w-3 h-3 bg-amber-700 rounded-full"></span>
              Session: {sessionTaps} taps
            </p>
            <p className="flex items-center justify-center gap-2">
              <span className="inline-block w-3 h-3 bg-stone-800 rounded-full"></span>
              Your total: {totalTaps} taps
            </p>
            <p className="text-amber-300 font-semibold flex items-center justify-center gap-2">
              <span className="inline-block w-3 h-3 bg-gradient-to-r from-amber-700 to-amber-800 rounded-full"></span>
              Community: {communityTaps.toLocaleString()} taps
            </p>
          </div>
        </div>
      </div>

      {/* Footer Stats */}
      <div className="mt-12 text-center text-gray-100 text-sm z-10">
        <p className="text-amber-300 font-semibold">
          🌍 {communityTaps.toLocaleString()} taps worldwide!
        </p>
      </div>
    </div>
  );
}
